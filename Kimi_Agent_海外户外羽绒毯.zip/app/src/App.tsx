import { useEffect, useRef } from 'react'
import Lenis from 'lenis'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import Navigation from './sections/Navigation'
import HeroSection from './sections/HeroSection'
import BrandStatement from './sections/BrandStatement'
import MaterialVideo from './sections/MaterialVideo'
import FeaturesGrid from './sections/FeaturesGrid'
import ScenariosShowcase from './sections/ScenariosShowcase'
import ProductLineup from './sections/ProductLineup'
import FinalCTA from './sections/FinalCTA'
import Footer from './sections/Footer'

gsap.registerPlugin(ScrollTrigger)

export default function App() {
  const lenisRef = useRef<Lenis | null>(null)

  useEffect(() => {
    const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    if (prefersReduced) return

    const lenis = new Lenis({
      lerp: 0.08,
      duration: 1.2,
    })
    lenisRef.current = lenis

    lenis.on('scroll', ScrollTrigger.update)

    gsap.ticker.add((time) => {
      lenis.raf(time * 1000)
    })
    gsap.ticker.lagSmoothing(0)

    return () => {
      lenis.destroy()
      gsap.ticker.remove(lenis.raf as any)
    }
  }, [])

  return (
    <div className="relative">
      <Navigation />
      <HeroSection />
      <BrandStatement />
      <MaterialVideo />
      <FeaturesGrid />
      <ScenariosShowcase />
      <ProductLineup />
      <FinalCTA />
      <Footer />
    </div>
  )
}
