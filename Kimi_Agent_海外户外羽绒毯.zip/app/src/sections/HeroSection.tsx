import { useEffect, useRef } from 'react'
import { Play } from 'lucide-react'
import gsap from 'gsap'

export default function HeroSection() {
  const sectionRef = useRef<HTMLDivElement>(null)
  const labelRef = useRef<HTMLParagraphElement>(null)
  const headlineRef = useRef<HTMLHeadingElement>(null)
  const subRef = useRef<HTMLParagraphElement>(null)
  const ctaRef = useRef<HTMLDivElement>(null)
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        labelRef.current,
        { opacity: 0, y: 20 },
        { opacity: 1, y: 0, duration: 0.6, delay: 0.4, ease: 'power3.out' }
      )
      gsap.fromTo(
        headlineRef.current,
        { opacity: 0, y: 30 },
        { opacity: 1, y: 0, duration: 0.8, delay: 0.6, ease: 'power3.out' }
      )
      gsap.fromTo(
        subRef.current,
        { opacity: 0, y: 20 },
        { opacity: 1, y: 0, duration: 0.7, delay: 0.9, ease: 'power3.out' }
      )
      gsap.fromTo(
        ctaRef.current,
        { opacity: 0, y: 20 },
        { opacity: 1, y: 0, duration: 0.6, delay: 1.1, ease: 'power3.out' }
      )
    }, sectionRef)

    const handleScroll = () => {
      if (scrollRef.current) {
        const opacity = Math.max(0, 1 - window.scrollY / 100)
        scrollRef.current.style.opacity = String(opacity)
      }
    }
    window.addEventListener('scroll', handleScroll, { passive: true })

    return () => {
      ctx.revert()
      window.removeEventListener('scroll', handleScroll)
    }
  }, [])

  return (
    <section
      ref={sectionRef}
      className="relative w-full min-h-[100dvh] overflow-hidden"
    >
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: 'url(/images/hero-bg.jpg)',
          animation: 'heroZoom 8s linear forwards',
        }}
      />

      <div
        className="absolute inset-0"
        style={{
          background:
            'linear-gradient(to bottom, transparent 60%, rgba(15,31,23,0.6) 100%)',
        }}
      />

      <div
        className="absolute bottom-[15vh] left-0 max-w-[600px]"
        style={{ paddingLeft: 'clamp(24px, 4vw, 80px)' }}
      >
        <p
          ref={labelRef}
          className="font-sans text-[12px] font-medium tracking-[0.08em] text-sand-400 uppercase mb-4 opacity-0"
        >
          PREMIUM DOWN OUTDOOR BLANKET
        </p>
        <h1
          ref={headlineRef}
          className="font-serif text-cream-100 opacity-0"
          style={{
            fontSize: 'clamp(48px, 6vw, 80px)',
            letterSpacing: '-0.02em',
            lineHeight: 1.05,
          }}
        >
          <span className="text-shadow-warm">Warmth</span> That Goes Where You Go
        </h1>
        <p
          ref={subRef}
          className="font-sans text-[16px] leading-[1.65] text-fog-300 mt-5 max-w-[480px] opacity-0"
        >
          From alpine sunrises to desert stargazing. One blanket. Every terrain.
        </p>
        <div ref={ctaRef} className="flex items-center gap-4 mt-8 opacity-0 flex-wrap">
          <button className="bg-sand-400 text-forest-900 font-sans text-[14px] font-medium tracking-[0.06em] uppercase px-8 py-3.5 rounded-sm transition-colors duration-250 hover:bg-sand-300 active:scale-[0.98]">
            SHOP THE COLLECTION
          </button>
          <button className="border border-cream-200 text-cream-100 font-sans text-[14px] font-medium tracking-[0.06em] uppercase px-6 py-3.5 rounded-sm transition-all duration-250 hover:bg-cream-100/10 hover:border-sand-400 flex items-center gap-2 active:scale-[0.98]">
            <Play size={16} fill="currentColor" />
            WATCH THE FILM
          </button>
        </div>
      </div>

      <div
        ref={scrollRef}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center"
      >
        <div className="w-px h-10 bg-sand-400/50 relative overflow-hidden">
          <div className="w-full h-2 bg-sand-400 rounded-full animate-scroll-dot" />
        </div>
      </div>

      <style>{`
        @keyframes heroZoom {
          from { transform: scale(1.05); }
          to { transform: scale(1.0); }
        }
      `}</style>
    </section>
  )
}
