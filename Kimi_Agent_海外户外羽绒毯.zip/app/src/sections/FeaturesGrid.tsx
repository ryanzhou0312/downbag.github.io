import { useEffect, useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

const features = [
  {
    image: '/images/feature1.jpg',
    title: '800-Fill European Goose Down',
    body: 'Responsibly sourced, RDS-certified down with a fill power of 800. Lighter, warmer, and more compressible than synthetic alternatives. Tracked from farm to factory.',
  },
  {
    image: '/images/feature2.jpg',
    title: 'Packs to the Size of a Water Bottle',
    body: 'Weighs just 1.2 lbs and compresses into an integrated stuff pocket. Toss it in your daypack and forget it\'s there \u2014 until the temperature drops.',
  },
  {
    image: '/images/feature3.jpg',
    title: 'Storm-Ready DWR Coating',
    body: 'Our PFAS-free durable water repellent finish sheds rain, snow, and morning dew. The 20D ripstop nylon shell blocks wind and resists abrasion on rocky ground.',
  },
]

export default function FeaturesGrid() {
  const sectionRef = useRef<HTMLDivElement>(null)
  const headerRef = useRef<HTMLDivElement>(null)
  const cardsRef = useRef<(HTMLDivElement | null)[]>([])

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        headerRef.current?.children || [],
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.7,
          stagger: 0.1,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: headerRef.current,
            start: 'top 85%',
          },
        }
      )

      cardsRef.current.forEach((card, i) => {
        if (!card) return
        const img = card.querySelector('.feature-img')
        const text = card.querySelector('.feature-text')

        gsap.fromTo(
          img,
          { clipPath: 'inset(100% 0 0 0)' },
          {
            clipPath: 'inset(0% 0 0 0)',
            duration: 1,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: card,
              start: 'top 85%',
            },
            delay: i * 0.2,
          }
        )

        gsap.fromTo(
          text,
          { opacity: 0, y: 30 },
          {
            opacity: 1,
            y: 0,
            duration: 0.7,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: card,
              start: 'top 85%',
            },
            delay: i * 0.2 + 0.3,
          }
        )
      })
    }, sectionRef)

    return () => ctx.revert()
  }, [])

  return (
    <section
      ref={sectionRef}
      className="w-full bg-cream-100"
      style={{
        paddingTop: 'clamp(60px, 10vw, 160px)',
        paddingBottom: 'clamp(60px, 10vw, 160px)',
        paddingLeft: 'clamp(24px, 4vw, 80px)',
        paddingRight: 'clamp(24px, 4vw, 80px)',
      }}
    >
      <div ref={headerRef} className="mb-12 md:mb-16">
        <p className="font-sans text-[12px] font-medium tracking-[0.08em] text-ember-500 uppercase mb-4 opacity-0">
          WHY TERRAQUILT
        </p>
        <h2
          className="font-serif text-forest-900 opacity-0"
          style={{
            fontSize: 'clamp(36px, 4.5vw, 64px)',
            letterSpacing: '-0.02em',
            lineHeight: 1.1,
          }}
        >
          Engineered for the Elements
        </h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {features.map((feature, i) => (
          <div
            key={i}
            ref={(el) => { cardsRef.current[i] = el }}
          >
            <div className="feature-img overflow-hidden rounded-sm" style={{ aspectRatio: '4/5' }}>
              <img
                src={feature.image}
                alt={feature.title}
                className="w-full h-full object-cover"
                loading={i === 0 ? 'eager' : 'lazy'}
              />
            </div>
            <div className="feature-text mt-5 opacity-0">
              <h3 className="font-sans text-[24px] font-medium tracking-[-0.01em] leading-[1.3] text-forest-900">
                {feature.title}
              </h3>
              <p className="font-sans text-[16px] leading-[1.65] text-fog-400 mt-3 max-w-[320px]">
                {feature.body}
              </p>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}
