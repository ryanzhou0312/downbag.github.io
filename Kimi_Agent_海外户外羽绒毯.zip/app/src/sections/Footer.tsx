import { Instagram, Youtube } from 'lucide-react'

const footerLinks = {
  shop: ['All Blankets', 'Limited Editions', 'Accessories', 'Gift Cards'],
  company: ['Our Story', 'Sustainability', 'Journal', 'Careers'],
  support: ['Shipping & Returns', 'Care Guide', 'FAQ', 'Contact'],
}

export default function Footer() {
  return (
    <footer className="w-full bg-forest-800">
      <div
        style={{
          paddingTop: '80px',
          paddingBottom: '40px',
          paddingLeft: 'clamp(24px, 4vw, 80px)',
          paddingRight: 'clamp(24px, 4vw, 80px)',
        }}
      >
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10 lg:gap-8">
          <div>
            <h3 className="font-sans text-[24px] font-medium tracking-[-0.01em] leading-[1.3] text-cream-100 mb-4">
              JOIN THE WILD
            </h3>
            <div className="flex items-center gap-2 mb-4">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 bg-forest-700 border border-forest-700 rounded-sm px-4 py-2.5 font-sans text-[14px] text-cream-100 placeholder:text-fog-400 focus:outline-none focus:border-sand-400 transition-colors"
              />
              <button
                className="bg-sand-400 text-forest-900 px-4 py-2.5 rounded-sm transition-colors duration-200 hover:bg-sand-300"
                aria-label="Subscribe"
              >
                <svg
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M5 12h14M12 5l7 7-7 7" />
                </svg>
              </button>
            </div>
            <p className="font-sans text-[16px] leading-[1.65] text-fog-400">
              Early access to new drops and campfire stories.
            </p>
          </div>

          <div>
            <h4 className="font-sans text-[12px] font-medium tracking-[0.08em] text-cream-100 uppercase mb-4">
              SHOP
            </h4>
            <ul className="space-y-2.5">
              {footerLinks.shop.map((link) => (
                <li key={link}>
                  <a
                    href="#"
                    className="font-sans text-[16px] leading-[1.65] text-fog-400 transition-colors duration-200 hover:text-cream-100"
                  >
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-sans text-[12px] font-medium tracking-[0.08em] text-cream-100 uppercase mb-4">
              COMPANY
            </h4>
            <ul className="space-y-2.5">
              {footerLinks.company.map((link) => (
                <li key={link}>
                  <a
                    href="#"
                    className="font-sans text-[16px] leading-[1.65] text-fog-400 transition-colors duration-200 hover:text-cream-100"
                  >
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-sans text-[12px] font-medium tracking-[0.08em] text-cream-100 uppercase mb-4">
              SUPPORT
            </h4>
            <ul className="space-y-2.5">
              {footerLinks.support.map((link) => (
                <li key={link}>
                  <a
                    href="#"
                    className="font-sans text-[16px] leading-[1.65] text-fog-400 transition-colors duration-200 hover:text-cream-100"
                  >
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="border-t border-forest-700 mt-12 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-4 flex-wrap justify-center sm:justify-start">
            <span className="font-sans text-[14px] text-fog-400">
              &copy; 2026 Terraquilt
            </span>
            <a
              href="#"
              className="font-sans text-[14px] text-fog-400 transition-colors duration-200 hover:text-cream-100"
            >
              Privacy
            </a>
            <a
              href="#"
              className="font-sans text-[14px] text-fog-400 transition-colors duration-200 hover:text-cream-100"
            >
              Terms
            </a>
          </div>

          <div className="flex items-center gap-5">
            <a
              href="#"
              className="text-fog-400 transition-colors duration-200 hover:text-sand-400"
              aria-label="Instagram"
            >
              <Instagram size={20} />
            </a>
            <a
              href="#"
              className="text-fog-400 transition-colors duration-200 hover:text-sand-400"
              aria-label="Pinterest"
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="10" />
                <path d="M8 12c0-2.2 1.8-4 4-4s4 1.8 4 4-1.8 4-4 4" />
                <path d="M12 16v4" />
                <path d="M9 20c.5-2 1.5-4 3-4" />
              </svg>
            </a>
            <a
              href="#"
              className="text-fog-400 transition-colors duration-200 hover:text-sand-400"
              aria-label="YouTube"
            >
              <Youtube size={20} />
            </a>
          </div>
        </div>
      </div>
    </footer>
  )
}
