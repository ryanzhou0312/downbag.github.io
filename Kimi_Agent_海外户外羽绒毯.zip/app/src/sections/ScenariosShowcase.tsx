import { useEffect, useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

const scenarios = [
  {
    image: '/images/scenario1.jpg',
    label: 'DESERT NIGHTS',
    title: 'Under a Billion Stars',
    quote: 'The temperature dropped to 38\u00B0F. We didn\'t even notice. \u2014 Mia \u0026 James, Moab',
  },
  {
    image: '/images/scenario2.jpg',
    label: 'ALPINE DAWNS',
    title: 'Above the Cloud Line',
    quote: 'My morning ritual. Coffee, ridge line, and this blanket. \u2014 Chris, Cascades',
  },
  {
    image: '/images/scenario3.jpg',
    label: 'LAKESIDE CAMPFIRES',
    title: 'Stories by Firelight',
    quote: 'The kids fight over who gets the orange one. Every single trip. \u2014 The Parkers, Minnesota',
  },
]

export default function ScenariosShowcase() {
  const sectionRef = useRef<HTMLDivElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)
  const trackRef = useRef<HTMLDivElement>(null)
  const headerRef = useRef<HTMLDivElement>(null)
  const dotsRef = useRef<(HTMLButtonElement | null)[]>([])

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        headerRef.current?.children || [],
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.7,
          stagger: 0.1,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
          },
        }
      )

      const mm = gsap.matchMedia()

      mm.add('(min-width: 768px)', () => {
        const track = trackRef.current
        if (!track) return

        const cards = track.children
        const totalWidth = track.scrollWidth - window.innerWidth

        const scrollTween = gsap.to(track, {
          x: -totalWidth,
          ease: 'none',
          scrollTrigger: {
            trigger: containerRef.current,
            start: 'top top',
            end: () => `+=${totalWidth}`,
            pin: true,
            scrub: 1,
            invalidateOnRefresh: true,
            onUpdate: (self) => {
              const progress = self.progress
              const activeIndex = Math.min(
                Math.floor(progress * scenarios.length),
                scenarios.length - 1
              )
              dotsRef.current.forEach((dot, i) => {
                if (dot) {
                  dot.style.backgroundColor =
                    i === activeIndex ? '#C9A96E' : 'rgba(201, 169, 110, 0.4)'
                }
              })
            },
          },
        })

        Array.from(cards).forEach((card) => {
          const bg = (card as HTMLElement).querySelector('.scenario-bg')
          if (bg) {
            gsap.fromTo(
              bg,
              { x: '10%' },
              {
                x: '-10%',
                ease: 'none',
                scrollTrigger: {
                  trigger: containerRef.current,
                  start: 'top top',
                  end: () => `+=${totalWidth}`,
                  scrub: 1,
                },
              }
            )
          }
        })

        return () => {
          scrollTween.kill()
        }
      })

      return () => mm.revert()
    }, sectionRef)

    return () => ctx.revert()
  }, [])

  const goToSlide = (index: number) => {
    const track = trackRef.current
    if (!track) return
    const cards = track.children
    if (cards[index]) {
      const target = cards[index] as HTMLElement
      const scrollPos =
        (target.offsetLeft / (track.scrollWidth - window.innerWidth)) *
        (ScrollTrigger.getAll().find(
          (st) => st.vars.trigger === containerRef.current
        )?.end || 0)

      gsap.to(window, {
        scrollTo: {
          y: scrollPos,
          autoKill: false,
        },
        duration: 1,
        ease: 'power3.inOut',
      })
    }
  }

  return (
    <section
      ref={sectionRef}
      className="w-full bg-forest-900 overflow-hidden"
      style={{
        paddingTop: 'clamp(60px, 10vw, 160px)',
        paddingBottom: 'clamp(60px, 10vw, 160px)',
      }}
    >
      <div ref={headerRef} className="text-center mb-12 md:mb-16">
        <p className="font-sans text-[12px] font-medium tracking-[0.08em] text-sand-400 uppercase mb-4 opacity-0">
          EVERY TERRAIN
        </p>
        <h2
          className="font-serif text-cream-100 opacity-0"
          style={{
            fontSize: 'clamp(36px, 4.5vw, 64px)',
            letterSpacing: '-0.02em',
            lineHeight: 1.1,
          }}
        >
          Where Will You Take Yours?
        </h2>
      </div>

      <div ref={containerRef} className="relative">
        <div
          ref={trackRef}
          className="flex gap-6"
          style={{
            paddingLeft: 'clamp(24px, 4vw, 80px)',
            paddingRight: 'clamp(24px, 4vw, 80px)',
          }}
        >
          {scenarios.map((scenario, i) => (
            <div
              key={i}
              className="scenario-card relative flex-shrink-0 overflow-hidden rounded-sm"
              style={{
                width: '85vw',
                height: 'clamp(400px, 70vh, 700px)',
              }}
            >
              <div
                className="scenario-bg absolute inset-0 bg-cover bg-center"
                style={{
                  backgroundImage: `url(${scenario.image})`,
                  width: '120%',
                  left: '-10%',
                }}
              />
              <div
                className="absolute inset-0 pointer-events-none"
                style={{
                  background:
                    'linear-gradient(to bottom, transparent 40%, rgba(15,31,23,0.8) 100%)',
                }}
              />
              <div className="absolute bottom-0 left-0 p-8 md:p-12">
                <p className="font-sans text-[12px] font-medium tracking-[0.08em] text-sand-400 uppercase mb-3">
                  {scenario.label}
                </p>
                <h3 className="font-sans text-[24px] font-medium tracking-[-0.01em] leading-[1.3] text-cream-100 mb-3">
                  {scenario.title}
                </h3>
                <p className="font-sans text-[16px] leading-[1.65] italic text-fog-300 max-w-[400px]">
                  {scenario.quote}
                </p>
              </div>
            </div>
          ))}
        </div>

        <div className="hidden md:flex justify-center gap-3 mt-10">
          {scenarios.map((_, i) => (
            <button
              key={i}
              ref={(el) => { dotsRef.current[i] = el }}
              onClick={() => goToSlide(i)}
              className="w-2.5 h-2.5 rounded-full transition-colors duration-300"
              style={{
                backgroundColor:
                  i === 0 ? '#C9A96E' : 'rgba(201, 169, 110, 0.4)',
              }}
              aria-label={`Go to scenario ${i + 1}`}
            />
          ))}
        </div>
      </div>

      <style>{`
        @media (max-width: 767px) {
          .scenario-card {
            width: 100vw !important;
          }
        }
      `}</style>
    </section>
  )
}
