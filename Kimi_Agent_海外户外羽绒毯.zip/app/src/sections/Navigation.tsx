import { useEffect, useRef, useState } from 'react'
import { Menu, X } from 'lucide-react'

export default function Navigation() {
  const [scrolled, setScrolled] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)
  const navRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 80)
    }
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const navLinks = ['COLLECTION', 'STORIES', 'CARE', 'ABOUT']

  return (
    <>
      <nav
        ref={navRef}
        className={`fixed top-0 left-0 right-0 z-50 h-16 flex items-center justify-between transition-all duration-400 ${
          scrolled
            ? 'bg-forest-900/90 backdrop-blur-md'
            : 'bg-transparent'
        }`}
        style={{
          paddingLeft: 'clamp(24px, 4vw, 80px)',
          paddingRight: 'clamp(24px, 4vw, 80px)',
        }}
      >
        <a
          href="#"
          className="font-sans text-[13px] font-medium tracking-[0.06em] text-sand-400 uppercase"
        >
          TERRAQUILT
        </a>

        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <a
              key={link}
              href={`#${link.toLowerCase()}`}
              className="font-sans text-[13px] font-medium tracking-[0.06em] text-cream-100 uppercase transition-colors duration-200 hover:text-sand-400"
            >
              {link}
            </a>
          ))}
        </div>

        <div className="hidden md:flex items-center gap-6">
          <a
            href="#"
            className="font-sans text-[13px] font-medium tracking-[0.06em] text-cream-100 uppercase transition-colors duration-200 hover:text-sand-400"
          >
            ACCOUNT
          </a>
          <a
            href="#"
            className="font-sans text-[13px] font-medium tracking-[0.06em] text-cream-100 uppercase transition-colors duration-200 hover:text-sand-400"
          >
            CART (0)
          </a>
        </div>

        <button
          className="md:hidden text-cream-100"
          onClick={() => setMobileOpen(true)}
          aria-label="Open menu"
        >
          <Menu size={24} />
        </button>
      </nav>

      {mobileOpen && (
        <div className="fixed inset-0 z-[60] bg-forest-900 flex flex-col items-center justify-center gap-8">
          <button
            className="absolute top-5 right-5 text-cream-100"
            onClick={() => setMobileOpen(false)}
            aria-label="Close menu"
          >
            <X size={28} />
          </button>
          {navLinks.map((link) => (
            <a
              key={link}
              href={`#${link.toLowerCase()}`}
              onClick={() => setMobileOpen(false)}
              className="font-sans text-[18px] font-medium tracking-[0.06em] text-cream-100 uppercase"
            >
              {link}
            </a>
          ))}
          <div className="flex gap-6 mt-8">
            <a href="#" className="font-sans text-[13px] font-medium tracking-[0.06em] text-fog-400 uppercase">
              ACCOUNT
            </a>
            <a href="#" className="font-sans text-[13px] font-medium tracking-[0.06em] text-fog-400 uppercase">
              CART (0)
            </a>
          </div>
        </div>
      )}
    </>
  )
}
