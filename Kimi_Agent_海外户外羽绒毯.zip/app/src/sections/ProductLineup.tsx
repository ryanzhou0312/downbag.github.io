import { useEffect, useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

const products = [
  {
    image: '/images/product1.jpg',
    name: 'Terraquilt Original',
    price: 'From $149',
    specs: '1.2 lbs \u00B7 20D Nylon \u00B7 800 Fill',
    colors: ['#2A3F32', '#D9C49A', '#1A2E22'],
    colorNames: ['Forest', 'Sand', 'Navy'],
  },
  {
    image: '/images/product2.jpg',
    name: 'Terraquilt XL',
    price: 'From $189',
    specs: '1.8 lbs \u00B7 30D Nylon \u00B7 850 Fill',
    colors: ['#C45F2A', '#2A3F32', '#2D2D2D'],
    colorNames: ['Ember', 'Olive', 'Charcoal'],
  },
  {
    image: '/images/product3.jpg',
    name: 'Terraquilt Lite',
    price: 'From $119',
    specs: '0.9 lbs \u00B7 15D Nylon \u00B7 750 Fill',
    colors: ['#1A2E22', '#9BAA9E', '#D9C49A'],
    colorNames: ['Navy', 'Fog', 'Sand'],
  },
]

export default function ProductLineup() {
  const sectionRef = useRef<HTMLDivElement>(null)
  const headerRef = useRef<HTMLDivElement>(null)
  const cardsRef = useRef<(HTMLDivElement | null)[]>([])

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        headerRef.current?.children || [],
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.7,
          stagger: 0.1,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: headerRef.current,
            start: 'top 85%',
          },
        }
      )

      cardsRef.current.forEach((card, i) => {
        if (!card) return
        const img = card.querySelector('.product-img')
        const info = card.querySelector('.product-info')

        gsap.fromTo(
          img,
          { opacity: 0, scale: 0.95 },
          {
            opacity: 1,
            scale: 1,
            duration: 0.8,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: card,
              start: 'top 85%',
            },
            delay: i * 0.15,
          }
        )

        gsap.fromTo(
          info,
          { opacity: 0, y: 20 },
          {
            opacity: 1,
            y: 0,
            duration: 0.6,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: card,
              start: 'top 85%',
            },
            delay: i * 0.15 + 0.2,
          }
        )
      })
    }, sectionRef)

    return () => ctx.revert()
  }, [])

  return (
    <section
      ref={sectionRef}
      className="w-full bg-cream-100"
      style={{
        paddingTop: 'clamp(60px, 10vw, 160px)',
        paddingBottom: 'clamp(60px, 10vw, 160px)',
        paddingLeft: 'clamp(24px, 4vw, 80px)',
        paddingRight: 'clamp(24px, 4vw, 80px)',
      }}
      id="collection"
    >
      <div ref={headerRef} className="mb-12 md:mb-16">
        <p className="font-sans text-[12px] font-medium tracking-[0.08em] text-ember-500 uppercase mb-4 opacity-0">
          THE COLLECTION
        </p>
        <h2
          className="font-serif text-forest-900 opacity-0"
          style={{
            fontSize: 'clamp(36px, 4.5vw, 64px)',
            letterSpacing: '-0.02em',
            lineHeight: 1.1,
          }}
        >
          Find Your Warmth
        </h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {products.map((product, i) => (
          <div
            key={i}
            ref={(el) => { cardsRef.current[i] = el }}
            className="group cursor-pointer"
          >
            <div
              className="product-img relative bg-[#FAFAFA] border border-cream-200 rounded-sm overflow-hidden opacity-0"
              style={{ aspectRatio: '1/1' }}
            >
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
            </div>
            <div className="product-info mt-4 opacity-0">
              <div className="flex gap-2 mb-3">
                {product.colors.map((color, ci) => (
                  <div
                    key={ci}
                    className="w-4 h-4 rounded-full border"
                    style={{
                      backgroundColor: color,
                      borderColor: ci === 0 ? '#0F1F17' : 'transparent',
                      borderWidth: '2px',
                    }}
                    title={product.colorNames[ci]}
                  />
                ))}
              </div>
              <p className="font-sans text-[16px] font-medium text-forest-900">
                {product.name}
              </p>
              <p className="font-sans text-[16px] text-sand-400 mt-1">
                {product.price}
              </p>
              <p className="font-sans text-[12px] font-medium tracking-[0.08em] text-fog-400 uppercase mt-2">
                {product.specs}
              </p>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}
