import { useEffect, useRef, useState } from 'react'
import { Play } from 'lucide-react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

export default function MaterialVideo() {
  const sectionRef = useRef<HTMLDivElement>(null)
  const videoContainerRef = useRef<HTMLDivElement>(null)
  const textRef = useRef<HTMLDivElement>(null)
  const [playing, setPlaying] = useState(false)

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        videoContainerRef.current,
        { clipPath: 'inset(100% 0 0 0)' },
        {
          clipPath: 'inset(0% 0 0 0)',
          duration: 1.2,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
          },
        }
      )

      const textChildren = textRef.current?.children
      if (textChildren) {
        gsap.fromTo(
          textChildren,
          { opacity: 0, y: 30 },
          {
            opacity: 1,
            y: 0,
            duration: 0.8,
            stagger: 0.15,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: sectionRef.current,
              start: 'top 70%',
            },
          }
        )
      }
    }, sectionRef)

    return () => ctx.revert()
  }, [])

  return (
    <section
      ref={sectionRef}
      className="w-full bg-forest-900"
      style={{
        paddingTop: 'clamp(60px, 10vw, 160px)',
        paddingBottom: 'clamp(40px, 6vw, 100px)',
        paddingLeft: 'clamp(24px, 4vw, 80px)',
        paddingRight: 'clamp(24px, 4vw, 80px)',
      }}
    >
      <div
        ref={videoContainerRef}
        className="relative w-full overflow-hidden rounded-sm"
        style={{ height: 'clamp(400px, 70vh, 800px)' }}
      >
        <img
          src="/images/video1-poster.jpg"
          alt="The craft of Terraquilt blankets"
          className="w-full h-full object-cover"
        />

        {!playing && (
          <button
            onClick={() => setPlaying(true)}
            className="absolute inset-0 flex items-center justify-center bg-black/20 transition-all duration-200 hover:bg-black/30"
            aria-label="Play video"
          >
            <div className="w-16 h-16 rounded-full bg-sand-400 flex items-center justify-center transition-transform duration-200 hover:scale-105">
              <Play size={28} className="text-forest-900 ml-1" fill="currentColor" />
            </div>
          </button>
        )}

        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background:
              'linear-gradient(to bottom, transparent 50%, rgba(15,31,23,0.8) 100%)',
          }}
        />

        <div
          ref={textRef}
          className="absolute bottom-0 left-0 p-8 md:p-12"
        >
          <p className="font-sans text-[12px] font-medium tracking-[0.08em] text-sand-400 uppercase mb-3 opacity-0">
            THE CRAFT
          </p>
          <h2
            className="font-serif text-cream-100 opacity-0"
            style={{
              fontSize: 'clamp(36px, 4.5vw, 64px)',
              letterSpacing: '-0.02em',
              lineHeight: 1.1,
            }}
          >
            Every Thread Tells a Story
          </h2>
          <p className="font-sans text-[16px] leading-[1.65] text-fog-300 mt-4 max-w-[480px] opacity-0">
            From ethically sourced European goose down to recycled ripstop nylon woven in Italy. We trace every material to its origin, because what wraps you at night matters.
          </p>
        </div>
      </div>
    </section>
  )
}
