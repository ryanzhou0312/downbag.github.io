import { useEffect, useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

export default function FinalCTA() {
  const sectionRef = useRef<HTMLDivElement>(null)
  const contentRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const ctx = gsap.context(() => {
      const bg = sectionRef.current?.querySelector('.cta-bg')
      if (bg) {
        gsap.fromTo(
          bg,
          { scale: 1 },
          {
            scale: 1.03,
            duration: 6,
            ease: 'none',
            yoyo: true,
            repeat: -1,
          }
        )
      }

      const children = contentRef.current?.children
      if (children) {
        gsap.fromTo(
          children,
          { opacity: 0, y: 30 },
          {
            opacity: 1,
            y: 0,
            duration: 0.8,
            stagger: 0.2,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: sectionRef.current,
              start: 'top 70%',
            },
          }
        )
      }
    }, sectionRef)

    return () => ctx.revert()
  }, [])

  return (
    <section
      ref={sectionRef}
      className="relative w-full overflow-hidden"
      style={{ minHeight: '60vh' }}
    >
      <div
        className="cta-bg absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: 'url(/images/lifestyle1.jpg)',
        }}
      />
      <div className="absolute inset-0 bg-forest-900/50" />

      <div
        ref={contentRef}
        className="relative z-10 flex flex-col items-center justify-center text-center"
        style={{
          minHeight: '60vh',
          paddingLeft: 'clamp(24px, 4vw, 80px)',
          paddingRight: 'clamp(24px, 4vw, 80px)',
        }}
      >
        <p className="font-sans text-[12px] font-medium tracking-[0.08em] text-sand-400 uppercase mb-4 opacity-0">
          READY FOR YOUR NEXT ADVENTURE?
        </p>
        <h2
          className="font-serif text-cream-100 opacity-0"
          style={{
            fontSize: 'clamp(48px, 6vw, 80px)',
            letterSpacing: '-0.02em',
            lineHeight: 1.05,
          }}
        >
          Get Out There. Stay Warm.
        </h2>
        <button className="mt-8 bg-sand-400 text-forest-900 font-sans text-[14px] font-medium tracking-[0.06em] uppercase px-12 py-4.5 rounded-sm transition-colors duration-250 hover:bg-sand-300 active:scale-[0.98] opacity-0">
          SHOP ALL BLANKETS
        </button>
        <p className="font-sans text-[16px] leading-[1.65] text-fog-300 mt-5 opacity-0">
          Free shipping over $99 \u00B7 60-night trial \u00B7 Lifetime warranty
        </p>
      </div>
    </section>
  )
}
