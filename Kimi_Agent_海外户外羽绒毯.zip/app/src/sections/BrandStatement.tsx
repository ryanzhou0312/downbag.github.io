import { useEffect, useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

export default function BrandStatement() {
  const sectionRef = useRef<HTMLDivElement>(null)
  const overlineRef = useRef<HTMLParagraphElement>(null)
  const statementRef = useRef<HTMLHeadingElement>(null)
  const signatureRef = useRef<HTMLParagraphElement>(null)

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        overlineRef.current,
        { opacity: 0, y: 20 },
        {
          opacity: 1,
          y: 0,
          duration: 0.5,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
          },
        }
      )

      const words = statementRef.current?.querySelectorAll('.word')
      if (words) {
        gsap.fromTo(
          words,
          { opacity: 0, y: 20 },
          {
            opacity: 1,
            y: 0,
            duration: 0.6,
            stagger: 0.03,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: sectionRef.current,
              start: 'top 80%',
            },
          }
        )
      }

      gsap.fromTo(
        signatureRef.current,
        { opacity: 0 },
        {
          opacity: 1,
          duration: 0.5,
          delay: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
          },
        }
      )
    }, sectionRef)

    return () => ctx.revert()
  }, [])

  const statementText =
    "We believe the best memories are made when you're a little cold, a little uncomfortable, and completely alive. Our blankets don't just keep you warm \u2014 they keep you out there longer."

  const words = statementText.split(' ')

  return (
    <section
      ref={sectionRef}
      className="w-full bg-cream-100"
      style={{
        paddingTop: 'clamp(60px, 10vw, 160px)',
        paddingBottom: 'clamp(60px, 10vw, 160px)',
        paddingLeft: 'clamp(24px, 4vw, 80px)',
        paddingRight: 'clamp(24px, 4vw, 80px)',
      }}
    >
      <div className="max-w-[800px] mx-auto text-center">
        <p
          ref={overlineRef}
          className="font-sans text-[12px] font-medium tracking-[0.08em] text-ember-500 uppercase mb-6 opacity-0"
        >
          BUILT FOR THE WILD
        </p>
        <h2
          ref={statementRef}
          className="font-serif text-forest-900 opacity-0"
          style={{
            fontSize: 'clamp(36px, 4.5vw, 64px)',
            letterSpacing: '-0.02em',
            lineHeight: 1.1,
          }}
        >
          {words.map((word, i) => (
            <span key={i} className="word inline-block mr-[0.3em] opacity-0">
              {word}
            </span>
          ))}
        </h2>
        <p
          ref={signatureRef}
          className="font-sans text-[16px] leading-[1.65] italic text-fog-400 mt-8 opacity-0"
        >
          &mdash; The Terraquilt Team
        </p>
      </div>
    </section>
  )
}
